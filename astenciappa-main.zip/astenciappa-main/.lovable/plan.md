

## App de Asistencia y Tiempo Extra

### 1. Pantalla de Configuración Inicial
- Registro del nombre del supervisor (se guarda localmente)
- Gestión de empleados: agregar, editar y eliminar empleados con nombre y puesto/área
- Los empleados se organizan por área o departamento

### 2. Registro de Asistencia Semanal
- Vista de la semana actual (Lunes a Domingo) en formato de tabla
- Filas = empleados, Columnas = días de la semana
- Cada celda es un checkbox para marcar asistencia (✓) o falta (✗)
- Selector de semana para navegar entre semanas anteriores y futuras
- Indicadores visuales: verde para asistencia, rojo para falta

### 3. Registro de Tiempo Extra
- En la misma vista semanal, columna adicional o sección para capturar horas extra por día por empleado
- Campo numérico para ingresar las horas extra trabajadas cada día
- Resumen automático del total de horas extra por empleado en la semana

### 4. Panel de Resumen
- Vista resumen de la semana con:
  - Total de días asistidos por empleado
  - Total de faltas por empleado
  - Total de horas extra por empleado
  - Porcentaje de asistencia general

### 5. Generación de PDF
- Botón "Generar Reporte PDF" que crea un documento con:
  - Encabezado con nombre del supervisor, área y fecha de la semana
  - Tabla de asistencia completa (empleado × día)
  - Columna de horas extra por día y total semanal
  - Espacio para firma del supervisor
- El PDF se descarga directamente al dispositivo

### 6. Almacenamiento Local
- Todos los datos (empleados, asistencia, tiempo extra) se guardan en localStorage
- Los registros persisten entre sesiones en el mismo navegador
- Opción para exportar/importar datos como respaldo (archivo JSON)

### Diseño
- Interfaz limpia y funcional, optimizada para uso en tablet o computadora
- Colores claros con acentos en azul para una apariencia profesional
- Navegación simple: Empleados → Asistencia → Reporte

