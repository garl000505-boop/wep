import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useAppData } from "@/hooks/useAppData";
import AppLayout from "@/components/AppLayout";
import EmployeesPage from "@/pages/EmployeesPage";
import AttendancePage from "@/pages/AttendancePage";
import ReportPage from "@/pages/ReportPage";
import ConfigPage from "@/pages/ConfigPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function AppContent() {
  const {
    data,
    setSupervisorName,
    setRestDays,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    setAttendance,
    setOvertime,
    getAttendance,
    getOvertime,
    exportData,
    importData,
  } = useAppData();

  return (
    <AppLayout supervisorNames={data.supervisorNames} onExport={exportData} onImport={importData}>
      <Routes>
        <Route
          path="/"
          element={
            <EmployeesPage
              employees={data.employees}
              onAdd={addEmployee}
              onUpdate={updateEmployee}
              onDelete={deleteEmployee}
            />
          }
        />
        <Route
          path="/asistencia"
          element={
            <AttendancePage
              employees={data.employees}
              getAttendance={getAttendance}
              setAttendance={setAttendance}
              getOvertime={getOvertime}
              setOvertime={setOvertime}
            />
          }
        />
        <Route
          path="/reporte"
          element={
            <ReportPage
              employees={data.employees}
              supervisorNames={data.supervisorNames}
              restDays={data.restDays}
              getAttendance={getAttendance}
              getOvertime={getOvertime}
            />
          }
        />
        <Route
          path="/config"
          element={
            <ConfigPage
              supervisorNames={data.supervisorNames}
              restDays={data.restDays}
              onNameChange={setSupervisorName}
              onRestDaysChange={setRestDays}
            />
          }
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </AppLayout>
  );
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppContent />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
