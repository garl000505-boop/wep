import { useState, useEffect, useCallback } from 'react';
import { AppData, Employee, Turno, TURNOS } from '@/types/attendance';

const STORAGE_KEY = 'attendance-app-data';

const defaultSupervisorNames = Object.fromEntries(TURNOS.map(t => [t, ''])) as Record<Turno, string>;
const defaultRestDays = Object.fromEntries(TURNOS.map(t => [t, []])) as Record<Turno, number[]>;

const defaultData: AppData = {
  supervisorName: '',
  supervisorNames: { ...defaultSupervisorNames },
  restDays: { ...defaultRestDays },
  employees: [],
  attendance: {},
  overtime: {},
};

function loadData(): AppData {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return { ...defaultData, ...JSON.parse(raw) };
  } catch {}
  return defaultData;
}

function saveData(data: AppData) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

export function useAppData() {
  const [data, setData] = useState<AppData>(loadData);

  useEffect(() => {
    saveData(data);
  }, [data]);

  const setSupervisorName = useCallback((turno: Turno, name: string) => {
    setData(prev => ({
      ...prev,
      supervisorNames: { ...prev.supervisorNames, [turno]: name },
    }));
  }, []);

  const setRestDays = useCallback((turno: Turno, days: number[]) => {
    setData(prev => ({
      ...prev,
      restDays: { ...prev.restDays, [turno]: days },
    }));
  }, []);

  const addEmployee = useCallback((emp: Omit<Employee, 'id'>) => {
    setData(prev => ({
      ...prev,
      employees: [...prev.employees, { ...emp, id: crypto.randomUUID() }],
    }));
  }, []);

  const updateEmployee = useCallback((id: string, emp: Omit<Employee, 'id'>) => {
    setData(prev => ({
      ...prev,
      employees: prev.employees.map(e => (e.id === id ? { ...emp, id } : e)),
    }));
  }, []);

  const deleteEmployee = useCallback((id: string) => {
    setData(prev => ({
      ...prev,
      employees: prev.employees.filter(e => e.id !== id),
    }));
  }, []);

  const setAttendance = useCallback((employeeId: string, weekKey: string, dayIndex: number, present: boolean) => {
    const key = `${employeeId}-${weekKey}-${dayIndex}`;
    setData(prev => ({
      ...prev,
      attendance: { ...prev.attendance, [key]: present },
    }));
  }, []);

  const setOvertime = useCallback((employeeId: string, weekKey: string, dayIndex: number, hours: number) => {
    const key = `${employeeId}-${weekKey}-${dayIndex}`;
    setData(prev => ({
      ...prev,
      overtime: { ...prev.overtime, [key]: hours },
    }));
  }, []);

  const getAttendance = useCallback((employeeId: string, weekKey: string, dayIndex: number): boolean => {
    return data.attendance[`${employeeId}-${weekKey}-${dayIndex}`] ?? false;
  }, [data.attendance]);

  const getOvertime = useCallback((employeeId: string, weekKey: string, dayIndex: number): number => {
    return data.overtime[`${employeeId}-${weekKey}-${dayIndex}`] ?? 0;
  }, [data.overtime]);

  const exportData = useCallback(() => {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `asistencia-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }, [data]);

  const importData = useCallback((file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const imported = JSON.parse(e.target?.result as string) as AppData;
        setData({ ...defaultData, ...imported });
      } catch {
        alert('Error al importar el archivo');
      }
    };
    reader.readAsText(file);
  }, []);

  return {
    data,
    setSupervisorName,
    setRestDays,
    addEmployee,
    updateEmployee,
    deleteEmployee,
    setAttendance,
    setOvertime,
    getAttendance,
    getOvertime,
    exportData,
    importData,
  };
}
