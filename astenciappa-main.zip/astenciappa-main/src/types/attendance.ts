export type Turno = 'Turno 1' | 'Turno 2' | 'Turno 3';

export const TURNOS: Turno[] = ['Turno 1', 'Turno 2', 'Turno 3'];

export interface Employee {
  id: string;
  name: string;
  position: string;
  area: string;
  turno: Turno;
}

export interface AttendanceRecord {
  // key: `${employeeId}-${weekKey}-${dayIndex}`
  [key: string]: boolean;
}

export interface OvertimeRecord {
  // key: `${employeeId}-${weekKey}-${dayIndex}`
  [key: string]: number;
}

export type SupervisorNames = Record<Turno, string>;

export type RestDays = Record<Turno, number[]>;

export interface AppData {
  supervisorName: string; // legacy, kept for backwards compat
  supervisorNames: SupervisorNames;
  restDays: RestDays;
  employees: Employee[];
  attendance: AttendanceRecord;
  overtime: OvertimeRecord;
}

export const DAYS = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'] as const;

export const DAYS_SHORT = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'] as const;
