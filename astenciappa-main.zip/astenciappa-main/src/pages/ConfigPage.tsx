import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Turno, TURNOS, DAYS, SupervisorNames, RestDays } from '@/types/attendance';

interface ConfigPageProps {
  supervisorNames: SupervisorNames;
  restDays: RestDays;
  onNameChange: (turno: Turno, name: string) => void;
  onRestDaysChange: (turno: Turno, days: number[]) => void;
}

export default function ConfigPage({ supervisorNames, restDays, onNameChange, onRestDaysChange }: ConfigPageProps) {
  const toggleRestDay = (turno: Turno, dayIndex: number) => {
    const current = restDays[turno] || [];
    const updated = current.includes(dayIndex)
      ? current.filter(d => d !== dayIndex)
      : [...current, dayIndex];
    onRestDaysChange(turno, updated);
  };

  return (
    <div className="max-w-lg space-y-6">
      <h2 className="text-2xl font-bold text-foreground">Configuración</h2>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Supervisores por Turno</CardTitle>
          <CardDescription>Estos nombres aparecerán en los reportes PDF generados</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {TURNOS.map(turno => (
            <div key={turno} className="space-y-2">
              <Label htmlFor={`supervisor-${turno}`}>Supervisor {turno}</Label>
              <Input
                id={`supervisor-${turno}`}
                value={supervisorNames[turno] || ''}
                onChange={e => onNameChange(turno, e.target.value)}
                placeholder={`Ej: Ing. María López (${turno})`}
              />
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Días de Descanso por Turno</CardTitle>
          <CardDescription>Los días marcados no contarán como falta en el reporte</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {TURNOS.map(turno => (
            <div key={turno} className="space-y-2">
              <Label className="font-semibold">{turno}</Label>
              <div className="flex flex-wrap gap-3">
                {DAYS.map((day, i) => (
                  <label key={i} className="flex items-center gap-1.5 text-sm cursor-pointer">
                    <Checkbox
                      checked={(restDays[turno] || []).includes(i)}
                      onCheckedChange={() => toggleRestDay(turno, i)}
                    />
                    {day}
                  </label>
                ))}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
