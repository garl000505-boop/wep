import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ChevronLeft, ChevronRight, FileDown } from 'lucide-react';
import { Employee, DAYS_SHORT, TURNOS, SupervisorNames, RestDays } from '@/types/attendance';
import { getWeekKey, getWeekLabel, navigateWeek } from '@/lib/weekUtils';
import { generatePDF } from '@/lib/pdfGenerator';

interface ReportPageProps {
  employees: Employee[];
  supervisorNames: SupervisorNames;
  restDays: RestDays;
  getAttendance: (empId: string, weekKey: string, day: number) => boolean;
  getOvertime: (empId: string, weekKey: string, day: number) => number;
}

export default function ReportPage({ employees, supervisorNames, restDays, getAttendance, getOvertime }: ReportPageProps) {
  const [weekKey, setWeekKey] = useState(getWeekKey(new Date()));

  const getSummary = (emp: Employee) => {
    const empRestDays = restDays[emp.turno] || [];
    let attended = 0;
    let absences = 0;
    let totalOT = 0;
    for (let i = 0; i < 7; i++) {
      if (empRestDays.includes(i)) continue; // skip rest days
      if (getAttendance(emp.id, weekKey, i)) attended++;
      else absences++;
      totalOT += getOvertime(emp.id, weekKey, i);
    }
    return { emp, attended, absences, totalOT, workDays: 7 - empRestDays.length };
  };

  const summaryData = employees.map(getSummary);

  const totalAttended = summaryData.reduce((s, d) => s + d.attended, 0);
  const totalWorkDays = summaryData.reduce((s, d) => s + d.workDays, 0);
  const attendancePercent = totalWorkDays > 0 ? Math.round((totalAttended / totalWorkDays) * 100) : 0;
  const totalOTAll = summaryData.reduce((s, d) => s + d.totalOT, 0);
  const totalAbsences = summaryData.reduce((s, d) => s + d.absences, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-foreground">Reporte Semanal</h2>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => setWeekKey(k => navigateWeek(k, -1))}>
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="text-sm font-medium min-w-[200px] text-center">{getWeekLabel(weekKey)}</span>
          <Button variant="outline" size="icon" onClick={() => setWeekKey(k => navigateWeek(k, 1))}>
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-3xl font-bold text-primary">{employees.length}</p>
            <p className="text-sm text-muted-foreground">Empleados</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-3xl font-bold text-green-600">{totalAttended}</p>
            <p className="text-sm text-muted-foreground">Asistencias</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-3xl font-bold text-red-500">{totalAbsences}</p>
            <p className="text-sm text-muted-foreground">Faltas</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-3xl font-bold text-primary">{attendancePercent}%</p>
            <p className="text-sm text-muted-foreground">Asistencia General</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <p className="text-3xl font-bold text-primary">{totalOTAll}h</p>
            <p className="text-sm text-muted-foreground">Tiempo Extra Total</p>
          </CardContent>
        </Card>
      </div>

      {/* Per-shift summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {TURNOS.map(turno => {
          const turnoEmps = summaryData.filter(d => (d.emp.turno || 'Turno 1') === turno);
          const tAttended = turnoEmps.reduce((s, d) => s + d.attended, 0);
          const tWorkDays = turnoEmps.reduce((s, d) => s + d.workDays, 0);
          const tPercent = tWorkDays > 0 ? Math.round((tAttended / tWorkDays) * 100) : 0;
          const tOT = turnoEmps.reduce((s, d) => s + d.totalOT, 0);
          return (
            <Card key={turno}>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">{turno}</CardTitle>
              </CardHeader>
              <CardContent className="flex justify-between text-sm">
                <span>{turnoEmps.length} emp.</span>
                <span className="text-green-600">{tPercent}% asist.</span>
                <span className="text-muted-foreground">{tOT}h extra</span>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Detail tables separated by turno */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Detalle por Turno</h3>
        <Button
          onClick={() => generatePDF(employees, supervisorNames, restDays, weekKey, getAttendance, getOvertime)}
          disabled={employees.length === 0}
        >
          <FileDown className="h-4 w-4 mr-2" />
          Generar PDF
        </Button>
      </div>

      {TURNOS.map(turno => {
        const turnoData = summaryData.filter(d => (d.emp.turno || 'Turno 1') === turno);
        if (turnoData.length === 0) return null;
        const turnoRestDays = restDays[turno] || [];

        return (
          <Card key={turno}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{turno} — {supervisorNames[turno] || 'Sin supervisor'}</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Empleado</TableHead>
                      <TableHead>Área</TableHead>
                      {DAYS_SHORT.map((d, i) => (
                        <TableHead key={d} className={`text-center ${turnoRestDays.includes(i) ? 'text-muted-foreground/50' : ''}`}>
                          {d}{turnoRestDays.includes(i) ? ' 🛌' : ''}
                        </TableHead>
                      ))}
                      <TableHead className="text-center">Asist.</TableHead>
                      <TableHead className="text-center">Faltas</TableHead>
                      <TableHead className="text-center">T. Extra</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {turnoData.map(({ emp, attended, absences, totalOT }) => (
                      <TableRow key={emp.id}>
                        <TableCell className="font-medium">{emp.name}</TableCell>
                        <TableCell className="text-muted-foreground">{emp.area || '—'}</TableCell>
                        {DAYS_SHORT.map((_, i) => {
                          const isRest = turnoRestDays.includes(i);
                          if (isRest) {
                            return (
                              <TableCell key={i} className="text-center text-muted-foreground/50 text-xs">
                                DESC
                              </TableCell>
                            );
                          }
                          const present = getAttendance(emp.id, weekKey, i);
                          const ot = getOvertime(emp.id, weekKey, i);
                          return (
                            <TableCell key={i} className="text-center">
                              <span className={present ? 'text-green-600 font-bold' : 'text-red-400'}>
                                {present ? '✓' : '✗'}
                              </span>
                              {ot > 0 && <span className="block text-xs text-muted-foreground">+{ot}h</span>}
                            </TableCell>
                          );
                        })}
                        <TableCell className="text-center font-bold text-green-600">{attended}</TableCell>
                        <TableCell className="text-center font-bold text-red-500">{absences}</TableCell>
                        <TableCell className="text-center font-bold">{totalOT}h</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
