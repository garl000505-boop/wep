import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ChevronLeft, ChevronRight, CalendarCheck } from 'lucide-react';
import { Employee, DAYS_SHORT, Turno, TURNOS } from '@/types/attendance';
import { getWeekKey, getWeekLabel, navigateWeek } from '@/lib/weekUtils';

interface AttendancePageProps {
  employees: Employee[];
  getAttendance: (empId: string, weekKey: string, day: number) => boolean;
  setAttendance: (empId: string, weekKey: string, day: number, val: boolean) => void;
  getOvertime: (empId: string, weekKey: string, day: number) => number;
  setOvertime: (empId: string, weekKey: string, day: number, val: number) => void;
}

export default function AttendancePage({
  employees,
  getAttendance,
  setAttendance,
  getOvertime,
  setOvertime,
}: AttendancePageProps) {
  const [weekKey, setWeekKey] = useState(getWeekKey(new Date()));
  const [filterTurno, setFilterTurno] = useState<Turno | 'todos'>('todos');

  const filtered = filterTurno === 'todos' ? employees : employees.filter(e => e.turno === filterTurno);

  if (employees.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
          <CalendarCheck className="h-12 w-12 mb-4 opacity-40" />
          <p className="text-lg font-medium">Primero agrega empleados</p>
          <p className="text-sm">Ve a la sección de Empleados para comenzar</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h2 className="text-2xl font-bold text-foreground">Asistencia Semanal</h2>
        <div className="flex items-center gap-3">
          <Select value={filterTurno} onValueChange={(v) => setFilterTurno(v as Turno | 'todos')}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos</SelectItem>
              {TURNOS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={() => setWeekKey(k => navigateWeek(k, -1))}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="text-sm font-medium min-w-[200px] text-center">{getWeekLabel(weekKey)}</span>
            <Button variant="outline" size="icon" onClick={() => setWeekKey(k => navigateWeek(k, 1))}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Attendance table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Asistencia</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 bg-card z-10 min-w-[150px]">Empleado</TableHead>
                  <TableHead className="min-w-[80px]">Turno</TableHead>
                  {DAYS_SHORT.map(day => (
                    <TableHead key={day} className="text-center min-w-[60px]">{day}</TableHead>
                  ))}
                  <TableHead className="text-center font-bold">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(emp => {
                  const total = DAYS_SHORT.reduce((sum, _, i) => sum + (getAttendance(emp.id, weekKey, i) ? 1 : 0), 0);
                  return (
                    <TableRow key={emp.id}>
                      <TableCell className="sticky left-0 bg-card z-10 font-medium">{emp.name}</TableCell>
                      <TableCell className="text-muted-foreground text-xs">{emp.turno || 'T1'}</TableCell>
                      {DAYS_SHORT.map((_, i) => {
                        const present = getAttendance(emp.id, weekKey, i);
                        return (
                          <TableCell key={i} className="text-center">
                            <Checkbox
                              checked={present}
                              onCheckedChange={(checked) => setAttendance(emp.id, weekKey, i, !!checked)}
                              className={present ? 'border-green-500 data-[state=checked]:bg-green-500' : 'border-red-300'}
                            />
                          </TableCell>
                        );
                      })}
                      <TableCell className="text-center font-bold">{total}/7</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Overtime table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Tiempo Extra (horas)</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 bg-card z-10 min-w-[150px]">Empleado</TableHead>
                  <TableHead className="min-w-[80px]">Turno</TableHead>
                  {DAYS_SHORT.map(day => (
                    <TableHead key={day} className="text-center min-w-[70px]">{day}</TableHead>
                  ))}
                  <TableHead className="text-center font-bold">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map(emp => {
                  const totalOT = DAYS_SHORT.reduce((sum, _, i) => sum + getOvertime(emp.id, weekKey, i), 0);
                  return (
                    <TableRow key={emp.id}>
                      <TableCell className="sticky left-0 bg-card z-10 font-medium">{emp.name}</TableCell>
                      <TableCell className="text-muted-foreground text-xs">{emp.turno || 'T1'}</TableCell>
                      {DAYS_SHORT.map((_, i) => (
                        <TableCell key={i} className="text-center p-1">
                          <Input
                            type="number"
                            min={0}
                            max={24}
                            step={0.5}
                            value={getOvertime(emp.id, weekKey, i) || ''}
                            onChange={e => setOvertime(emp.id, weekKey, i, parseFloat(e.target.value) || 0)}
                            className="w-16 text-center mx-auto h-8 text-sm"
                          />
                        </TableCell>
                      ))}
                      <TableCell className="text-center font-bold">{totalOT}h</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
