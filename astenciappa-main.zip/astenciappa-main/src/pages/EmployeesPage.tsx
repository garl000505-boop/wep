import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Pencil, Trash2, Users } from 'lucide-react';
import { Employee, Turno, TURNOS } from '@/types/attendance';

interface EmployeesPageProps {
  employees: Employee[];
  onAdd: (emp: Omit<Employee, 'id'>) => void;
  onUpdate: (id: string, emp: Omit<Employee, 'id'>) => void;
  onDelete: (id: string) => void;
}

export default function EmployeesPage({ employees, onAdd, onUpdate, onDelete }: EmployeesPageProps) {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState({ name: '', position: '', area: '', turno: 'Turno 1' as Turno });
  const [filterTurno, setFilterTurno] = useState<Turno | 'todos'>('todos');

  const areas = [...new Set(employees.map(e => e.area).filter(Boolean))];

  const openAdd = () => {
    setEditingId(null);
    setForm({ name: '', position: '', area: '', turno: 'Turno 1' });
    setDialogOpen(true);
  };

  const openEdit = (emp: Employee) => {
    setEditingId(emp.id);
    setForm({ name: emp.name, position: emp.position, area: emp.area, turno: emp.turno || 'Turno 1' });
    setDialogOpen(true);
  };

  const handleSave = () => {
    if (!form.name.trim()) return;
    if (editingId) {
      onUpdate(editingId, form);
    } else {
      onAdd(form);
    }
    setDialogOpen(false);
  };

  const filtered = filterTurno === 'todos' ? employees : employees.filter(e => e.turno === filterTurno);

  const groupedByArea = filtered.reduce<Record<string, Employee[]>>((acc, emp) => {
    const area = emp.area || 'Sin área';
    if (!acc[area]) acc[area] = [];
    acc[area].push(emp);
    return acc;
  }, {});

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Empleados</h2>
          <p className="text-muted-foreground">{employees.length} empleados registrados</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={filterTurno} onValueChange={(v) => setFilterTurno(v as Turno | 'todos')}>
            <SelectTrigger className="w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="todos">Todos</SelectItem>
              {TURNOS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
            </SelectContent>
          </Select>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={openAdd}>
                <Plus className="h-4 w-4 mr-2" />
                Agregar Empleado
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{editingId ? 'Editar' : 'Nuevo'} Empleado</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Nombre completo</Label>
                  <Input
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Ej: Juan Pérez"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Puesto</Label>
                  <Input
                    value={form.position}
                    onChange={e => setForm(f => ({ ...f, position: e.target.value }))}
                    placeholder="Ej: Operador"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Área / Departamento</Label>
                  <Input
                    value={form.area}
                    onChange={e => setForm(f => ({ ...f, area: e.target.value }))}
                    placeholder="Ej: Producción"
                    list="areas-list"
                  />
                  <datalist id="areas-list">
                    {areas.map(a => <option key={a} value={a} />)}
                  </datalist>
                </div>
                <div className="space-y-2">
                  <Label>Turno</Label>
                  <Select value={form.turno} onValueChange={(v) => setForm(f => ({ ...f, turno: v as Turno }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {TURNOS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline">Cancelar</Button>
                </DialogClose>
                <Button onClick={handleSave}>Guardar</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Users className="h-12 w-12 mb-4 opacity-40" />
            <p className="text-lg font-medium">No hay empleados registrados</p>
            <p className="text-sm">Agrega empleados para comenzar a registrar asistencia</p>
          </CardContent>
        </Card>
      ) : (
        Object.entries(groupedByArea).map(([area, emps]) => (
          <Card key={area}>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">{area}</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Nombre</TableHead>
                    <TableHead>Puesto</TableHead>
                    <TableHead>Turno</TableHead>
                    <TableHead className="w-24 text-right">Acciones</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {emps.map(emp => (
                    <TableRow key={emp.id}>
                      <TableCell className="font-medium">{emp.name}</TableCell>
                      <TableCell className="text-muted-foreground">{emp.position}</TableCell>
                      <TableCell className="text-muted-foreground">{emp.turno || 'Turno 1'}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="icon" onClick={() => openEdit(emp)}>
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" onClick={() => onDelete(emp.id)}>
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        ))
      )}
    </div>
  );
}
