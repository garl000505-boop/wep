import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { Employee, DAYS, TURNOS, SupervisorNames, RestDays } from '@/types/attendance';
import { getWeekLabel } from '@/lib/weekUtils';

function drawBarChart(
  doc: jsPDF,
  x: number,
  y: number,
  width: number,
  height: number,
  title: string,
  labels: string[],
  values: number[],
  maxVal: number,
  colors: [number, number, number][],
) {
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(title, x + width / 2, y, { align: 'center' });

  const chartY = y + 8;
  const chartH = height - 20;
  const barWidth = Math.min(30, (width - 20) / labels.length - 4);
  const totalBarsWidth = labels.length * (barWidth + 4);
  const startX = x + (width - totalBarsWidth) / 2;

  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.3);
  doc.line(startX - 5, chartY + chartH, startX + totalBarsWidth, chartY + chartH);

  labels.forEach((label, i) => {
    const barX = startX + i * (barWidth + 4);
    const barH = maxVal > 0 ? (values[i] / maxVal) * chartH : 0;
    const barY = chartY + chartH - barH;

    const color = colors[i % colors.length];
    doc.setFillColor(color[0], color[1], color[2]);
    doc.rect(barX, barY, barWidth, barH, 'F');

    doc.setFontSize(8);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(60, 60, 60);
    doc.text(values[i].toString(), barX + barWidth / 2, barY - 2, { align: 'center' });

    doc.setFontSize(7);
    doc.setFont('helvetica', 'normal');
    doc.text(label, barX + barWidth / 2, chartY + chartH + 6, { align: 'center' });
  });

  doc.setTextColor(0, 0, 0);
}

export function generatePDF(
  employees: Employee[],
  supervisorNames: SupervisorNames,
  restDays: RestDays,
  weekKey: string,
  getAttendance: (empId: string, weekKey: string, day: number) => boolean,
  getOvertime: (empId: string, weekKey: string, day: number) => number,
) {
  const doc = new jsPDF({ orientation: 'landscape' });
  const weekLabel = getWeekLabel(weekKey);

  // Header
  doc.setFontSize(16);
  doc.text('Reporte de Tiempo Extra', 14, 20);
  doc.setFontSize(10);
  const supervisorLines = TURNOS
    .filter(t => supervisorNames[t])
    .map(t => `${t}: ${supervisorNames[t]}`);
  doc.text(supervisorLines.length > 0 ? supervisorLines.join('  |  ') : 'Supervisores: No especificados', 14, 28);
  doc.text(`Semana: ${weekLabel}`, 14, 34);
  doc.text(`Generado: ${new Date().toLocaleDateString('es-MX')}`, 14, 40);

  let currentY = 46;

  TURNOS.forEach(turno => {
    const turnoRestDays = restDays[turno] || [];
    const turnoEmps = employees.filter(e => (e.turno || 'Turno 1') === turno);
    
    // Only include employees with overtime
    const empsWithOT = turnoEmps.filter(emp => {
      let ot = 0;
      for (let i = 0; i < 7; i++) ot += getOvertime(emp.id, weekKey, i);
      return ot > 0;
    });
    
    if (empsWithOT.length === 0) return;

    if (currentY > 160) {
      doc.addPage();
      currentY = 20;
    }

    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(`${turno} — Supervisor: ${supervisorNames[turno] || 'No especificado'}`, 14, currentY);
    doc.setFont('helvetica', 'normal');
    currentY += 4;

    const dayHeaders = DAYS.map((d, i) => turnoRestDays.includes(i) ? `${d} (D)` : d);
    const head = [['#', 'Empleado', 'Área', ...dayHeaders, 'Asist.', 'Faltas', 'T. Extra']];
    
    const body = empsWithOT.map((emp, idx) => {
      let attended = 0;
      let absences = 0;
      let totalOT = 0;
      const dayCells = DAYS.map((_, i) => {
        if (turnoRestDays.includes(i)) {
          return 'DESC';
        }
        const present = getAttendance(emp.id, weekKey, i);
        const ot = getOvertime(emp.id, weekKey, i);
        if (present) attended++;
        else absences++;
        totalOT += ot;
        let cell = present ? '✓' : '✗';
        if (ot > 0) cell += ` (+${ot}h)`;
        return cell;
      });
      return [
        (idx + 1).toString(),
        emp.name,
        emp.area || '—',
        ...dayCells,
        attended.toString(),
        absences.toString(),
        `${totalOT}h`,
      ];
    });

    autoTable(doc, {
      startY: currentY,
      head,
      body,
      styles: { fontSize: 7, cellPadding: 2 },
      headStyles: { fillColor: [30, 64, 175], textColor: 255 },
      columnStyles: {
        0: { cellWidth: 8 },
        1: { cellWidth: 30 },
        2: { cellWidth: 22 },
      },
      didParseCell: (data) => {
        if (data.section === 'body' && data.column.index >= 3 && data.column.index <= 9) {
          const val = data.cell.raw as string;
          if (val === 'DESC') {
            data.cell.styles.textColor = [160, 160, 160];
            data.cell.styles.fontStyle = 'italic';
          } else if (val.startsWith('✓')) {
            data.cell.styles.textColor = [22, 163, 74]; // green
          } else if (val.startsWith('✗')) {
            data.cell.styles.textColor = [239, 68, 68]; // red
          }
        }
      },
    });

    currentY = (doc as any).lastAutoTable?.finalY + 10 || currentY + 40;
  });

  // Charts page
  doc.addPage();

  const turnoLabels: string[] = [];
  const turnoCompliance: number[] = [];
  const turnoOT: number[] = [];

  TURNOS.forEach(turno => {
    const turnoRestDays = restDays[turno] || [];
    const turnoEmps = employees.filter(e => (e.turno || 'Turno 1') === turno);
    let attended = 0;
    let ot = 0;
    let workDays = 0;
    turnoEmps.forEach(emp => {
      for (let i = 0; i < 7; i++) {
        if (turnoRestDays.includes(i)) continue;
        workDays++;
        if (getAttendance(emp.id, weekKey, i)) attended++;
        ot += getOvertime(emp.id, weekKey, i);
      }
    });
    turnoLabels.push(turno);
    turnoCompliance.push(workDays > 0 ? Math.round((attended / workDays) * 100) : 0);
    turnoOT.push(ot);
  });

  doc.setFontSize(14);
  doc.setFont('helvetica', 'bold');
  doc.text('Gráficas de Cumplimiento y Tiempo Extra', 148, 18, { align: 'center' });

  drawBarChart(doc, 15, 30, 125, 80, '% Cumplimiento por Turno', turnoLabels, turnoCompliance, 100,
    [[22, 163, 74], [59, 130, 246], [249, 115, 22]]);

  drawBarChart(doc, 155, 30, 125, 80, 'Horas Extra Acumuladas por Turno', turnoLabels, turnoOT,
    Math.max(...turnoOT, 1), [[30, 64, 175], [147, 51, 234], [234, 88, 12]]);

  const empOTData = employees.map(emp => {
    let ot = 0;
    for (let i = 0; i < 7; i++) ot += getOvertime(emp.id, weekKey, i);
    return { name: emp.name.split(' ')[0], ot };
  }).sort((a, b) => b.ot - a.ot).slice(0, 10).filter(d => d.ot > 0);

  if (empOTData.length > 0) {
    drawBarChart(doc, 15, 125, 270, 70, 'Top Empleados con más Horas Extra',
      empOTData.map(d => d.name), empOTData.map(d => d.ot),
      Math.max(...empOTData.map(d => d.ot), 1),
      [[30, 64, 175], [59, 130, 246], [22, 163, 74], [249, 115, 22], [147, 51, 234],
       [234, 88, 12], [16, 185, 129], [236, 72, 153], [99, 102, 241], [245, 158, 11]]);
  }

  // Signatures
  let sigX = 14;
  TURNOS.forEach(turno => {
    doc.setFontSize(10);
    doc.setFont('helvetica', 'normal');
    doc.text('_______________________________', sigX, 210);
    doc.text(`Firma ${turno}`, sigX, 216);
    doc.text(supervisorNames[turno] || '', sigX, 222);
    sigX += 90;
  });

  doc.save(`asistencia-${weekKey}.pdf`);
}
