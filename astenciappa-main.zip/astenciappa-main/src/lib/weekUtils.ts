import { startOfWeek, endOfWeek, addWeeks, format } from 'date-fns';
import { es } from 'date-fns/locale';

export function getWeekKey(date: Date): string {
  const start = startOfWeek(date, { weekStartsOn: 1 });
  return format(start, 'yyyy-MM-dd');
}

export function getWeekRange(weekKey: string): { start: Date; end: Date } {
  const start = new Date(weekKey + 'T00:00:00');
  const end = endOfWeek(start, { weekStartsOn: 1 });
  return { start, end };
}

export function getWeekLabel(weekKey: string): string {
  const { start, end } = getWeekRange(weekKey);
  return `${format(start, "d 'de' MMM", { locale: es })} – ${format(end, "d 'de' MMM yyyy", { locale: es })}`;
}

export function navigateWeek(weekKey: string, direction: number): string {
  const current = new Date(weekKey + 'T00:00:00');
  const next = addWeeks(current, direction);
  return getWeekKey(next);
}
