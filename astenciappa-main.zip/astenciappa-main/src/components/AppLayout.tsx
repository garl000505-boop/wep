import { ReactNode } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Users, CalendarCheck, FileText, Settings, Download, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { SupervisorNames, TURNOS } from '@/types/attendance';

interface AppLayoutProps {
  children: ReactNode;
  supervisorNames: SupervisorNames;
  onExport: () => void;
  onImport: (file: File) => void;
}

const navItems = [
  { to: '/asistencia', icon: CalendarCheck, label: 'Asistencia' },
  { to: '/reporte', icon: FileText, label: 'Reporte' },
  { to: '/', icon: Users, label: 'Empleados' },
  { to: '/config', icon: Settings, label: 'Config' },
];

export default function AppLayout({ children, supervisorNames, onExport, onImport }: AppLayoutProps) {
  const location = useLocation();
  const activeSupervisors = TURNOS.filter(t => supervisorNames[t]).map(t => `${t}: ${supervisorNames[t]}`);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-card shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CalendarCheck className="h-7 w-7 text-primary" />
            <div>
              <h1 className="text-lg font-bold text-foreground">Asistencia & Tiempo Extra</h1>
              {activeSupervisors.length > 0 && (
                <p className="text-xs text-muted-foreground">{activeSupervisors.join(' | ')}</p>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" onClick={onExport} title="Exportar datos">
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">Exportar</span>
            </Button>
            <Button
              variant="ghost"
              size="sm"
              title="Importar datos"
              onClick={() => {
                const input = document.createElement('input');
                input.type = 'file';
                input.accept = '.json';
                input.onchange = (e) => {
                  const file = (e.target as HTMLInputElement).files?.[0];
                  if (file) onImport(file);
                };
                input.click();
              }}
            >
              <Upload className="h-4 w-4" />
              <span className="hidden sm:inline">Importar</span>
            </Button>
          </div>
        </div>
      </header>

      {/* Nav */}
      <nav className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 flex gap-1">
          {navItems.map(({ to, icon: Icon, label }) => (
            <Link
              key={to}
              to={to}
              className={cn(
                'flex items-center gap-2 px-4 py-3 text-sm font-medium border-b-2 transition-colors',
                location.pathname === to
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground hover:border-muted-foreground/30'
              )}
            >
              <Icon className="h-4 w-4" />
              {label}
            </Link>
          ))}
        </div>
      </nav>

      {/* Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-6">
        {children}
      </main>
    </div>
  );
}
